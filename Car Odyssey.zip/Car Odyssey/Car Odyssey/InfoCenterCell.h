//
//  InfoCenterCell.h
//  Car Odyssey
//
//  Created by 王澄宇 on 16/10/18.
//  Copyright © 2016年 Henry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoCenterCell : UITableViewCell
@property (nonatomic,strong)UILabel *titleL;
@property (nonatomic,strong)UILabel *dateL;
@property (nonatomic,strong)UILabel *conmentL;

@end
