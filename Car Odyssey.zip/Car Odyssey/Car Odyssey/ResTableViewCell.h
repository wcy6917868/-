//
//  ResTableViewCell.h
//  Car Odyssey
//
//  Created by 王澄宇 on 16/9/21.
//  Copyright © 2016年 Henry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResTableViewCell : UITableViewCell
@property (nonatomic,strong)UITextField *tf;
@property (nonatomic,strong)UILabel *label;
@property (nonatomic,strong)UIImageView* imageV;

@end
