//
//  ExplainViewController.h
//  Car Odyssey
//
//  Created by 王澄宇 on 16/10/10.
//  Copyright © 2016年 Henry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExplainViewController : UIViewController
@property (nonatomic,copy)NSString *APIStr;
@property (nonatomic,copy)NSString *titleStr;

@end
