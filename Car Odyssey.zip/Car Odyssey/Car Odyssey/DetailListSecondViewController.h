//
//  DetailListSecondViewController.h
//  Car Odyssey
//
//  Created by 王澄宇 on 16/10/12.
//  Copyright © 2016年 Henry. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JourneyModel.h"

@interface DetailListSecondViewController : UIViewController
@property (nonatomic,strong)JourneyModel*Jmodel;


@end
