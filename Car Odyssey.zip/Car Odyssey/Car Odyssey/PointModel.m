//
//  PointModel.m
//  Car Odyssey
//
//  Created by 王澄宇 on 16/10/13.
//  Copyright © 2016年 Henry. All rights reserved.
//

#import "PointModel.h"

@implementation PointModel

@end
