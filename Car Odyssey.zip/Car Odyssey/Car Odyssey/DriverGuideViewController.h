//
//  DriverGuideViewController.h
//  Car Odyssey
//
//  Created by 王澄宇 on 16/10/17.
//  Copyright © 2016年 Henry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DriverGuideViewController : UIViewController
@property (nonatomic,copy)NSString *WebStr;

@end
